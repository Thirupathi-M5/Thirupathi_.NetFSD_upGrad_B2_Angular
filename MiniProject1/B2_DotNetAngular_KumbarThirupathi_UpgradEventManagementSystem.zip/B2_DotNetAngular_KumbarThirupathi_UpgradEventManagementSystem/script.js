// =====================================================
// INDEXEDDB CONFIGURATION (Single Source of Truth)
// =====================================================

const DB_NAME = "upGradEMS_DB";
const DB_VERSION = 1;
const STORE_NAME = "events";

let db; // Global database connection

// Default events to seed the database (only if empty)
const DEFAULT_EVENTS = [
    {
        id: 1,
        name: "Tech Innovations Summit 2023",
        category: "Tech & Innovations",
        date: "2023-12-15",
        time: "10:00 AM",
        url: "https://upgrad.com/tech-summit",
        description: "Join us to explore the latest in AI and Cloud Computing."
    },
    {
        id: 2,
        name: "Industrial Automation Workshop",
        category: "Industrial Events",
        date: "2023-12-20",
        time: "14:00 PM",
        url: "https://upgrad.com/automation",
        description: "Learn about robotics and automation in manufacturing."
    },
    {
        id: 3,
        name: "Web Development Bootcamp",
        category: "Tech & Innovations",
        date: "2024-01-10",
        time: "11:00 AM",
        url: "https://upgrad.com/webdev",
        description: "A complete guide to Full Stack Development."
    }
];

// =====================================================
// INDEXEDDB FUNCTIONS (Shared by All Pages)
// =====================================================

// 1. Open/Create the Database
function openDatabase() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = function(event) {
            db = event.target.result;
            
            if (!db.objectStoreNames.contains(STORE_NAME)) {
                const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
                store.createIndex("name", "name", { unique: false });
                store.createIndex("category", "category", { unique: false });
                console.log("Database created successfully.");
            }
        };

        request.onsuccess = function(event) {
            db = event.target.result;
            console.log("Database opened successfully.");
            resolve(db);
        };

        request.onerror = function(event) {
            console.error("Database error:", event.target.error);
            reject("Error opening database");
        };
    });
}

// 2. Initialize Database with Default Events (if empty)
async function initializeDatabase() {
    try {
        await openDatabase();
        const events = await getAllEventsFromDB();
        
        // Only add default events if database is empty
        if (events.length === 0) {
            const transaction = db.transaction([STORE_NAME], "readwrite");
            const store = transaction.objectStore(STORE_NAME);
            
            DEFAULT_EVENTS.forEach(function(event) {
                store.add(event);
            });
            
            console.log("Default events added to database.");
        }
    } catch (error) {
        console.error("Initialization error:", error);
    }
}

// 3. Get All Events (READ)
function getAllEventsFromDB() {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], "readonly");
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = function() {
            resolve(request.result);
        };

        request.onerror = function(event) {
            console.error("Read error:", event.target.error);
            reject("Error fetching events");
        };
    });
}

// 4. Add a New Event (CREATE)
function addEventToDB(eventData) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], "readwrite");
        const store = transaction.objectStore(STORE_NAME);
        const request = store.add(eventData);

        request.onsuccess = function() {
            console.log("Event added:", eventData.id);
            resolve("Event added successfully!");
        };

        request.onerror = function(event) {
            console.error("Add error:", event.target.error);
            if (event.target.error.name === "ConstraintError") {
                reject("Error: Event ID already exists. Please use a unique ID.");
            } else {
                reject("Error adding event.");
            }
        };
    });
}

// 5. Delete an Event (DELETE)
function deleteEventFromDB(eventId) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], "readwrite");
        const store = transaction.objectStore(STORE_NAME);
        const request = store.delete(eventId);

        request.onsuccess = function() {
            console.log("Event deleted:", eventId);
            resolve("Event deleted successfully!");
        };

        request.onerror = function(event) {
            console.error("Delete error:", event.target.error);
            reject("Error deleting event");
        };
    });
}

// 6. Search Events
function searchEventsFromDB(searchTerm) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], "readonly");
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = function() {
            const allEvents = request.result;
            const lowerTerm = searchTerm.toLowerCase();
            
            const filtered = allEvents.filter(event => {
                return (
                    event.id.toString().includes(searchTerm) ||
                    event.name.toLowerCase().includes(lowerTerm) ||
                    event.category.toLowerCase().includes(lowerTerm)
                );
            });
            
            resolve(filtered);
        };

        request.onerror = function(event) {
            console.error("Search error:", event.target.error);
            reject("Error searching events");
        };
    });
}

// 7. Get Single Event by ID (for Registration Page)
function getEventByIdFromDB(eventId) {
    return new Promise((resolve, reject) => {
        const transaction = db.transaction([STORE_NAME], "readonly");
        const store = transaction.objectStore(STORE_NAME);
        const request = store.get(parseInt(eventId));

        request.onsuccess = function() {
            resolve(request.result);
        };

        request.onerror = function(event) {
            console.error("Get error:", event.target.error);
            reject("Error fetching event");
        };
    });
}

// =====================================================
// HOME PAGE FUNCTIONS (index.html)
// =====================================================

// Display Events as Bootstrap Cards on Home Page
function displayHomeEvents(events) {
    const container = document.getElementById("event-container");
    
    if (!container) return; // Not on home page

    container.innerHTML = "";

    if (events.length === 0) {
        container.innerHTML = `
            <div class="col-12 text-center">
                <p class="text-muted">No events available at the moment.</p>
            </div>
        `;
        return;
    }

    events.forEach(function(event) {
        const eventCard = `
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <span class="badge bg-info mb-2">${event.category}</span>
                        <h5 class="card-title">${event.name}</h5>
                        <p class="card-text text-muted">Date: ${event.date} | Time: ${event.time}</p>
                        <p class="card-text">${event.description}</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <button class="btn btn-primary w-100" onclick="registerForEvent(${event.id})">Register</button>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += eventCard;
    });
}

// Load Events on Home Page
async function loadHomeEvents() {
    const container = document.getElementById("event-container");
    
    if (!container) return; // Not on home page

    try {
        await openDatabase();
        const events = await getAllEventsFromDB();
        displayHomeEvents(events);
    } catch (error) {
        console.error("Error loading home events:", error);
        document.getElementById("event-container").innerHTML = 
            '<div class="col-12"><p class="text-danger">Error loading events. Please refresh.</p></div>';
    }
}

// Handle Register Button Click (Home Page)
function registerForEvent(eventId) {
    if (!eventId) {
        alert("Error: Event ID not found.");
        return;
    }
    window.location.href = "registration.html?id=" + eventId;
}

// =====================================================
// REGISTRATION PAGE FUNCTIONS (registration.html)
// =====================================================

// Load Event Details on Registration Page
async function loadRegistrationPage() {
    const regForm = document.getElementById("registrationForm");
    
    if (!regForm) return; // Not on registration page

    try {
        await openDatabase();
        
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('id');

        if (!eventId) {
            alert("Error: No event selected.");
            window.location.href = "index.html";
            return;
        }

        const event = await getEventByIdFromDB(eventId);

        if (event) {
            document.getElementById("displayEventId").value = event.id;
            document.getElementById("displayEventName").value = event.name;
            document.getElementById("displayCategory").value = event.category;
            document.getElementById("displayDate").value = event.date;
            document.getElementById("displayTime").value = event.time;
        } else {
            alert("Event not found!");
            window.location.href = "index.html";
        }
    } catch (error) {
        console.error("Error loading registration:", error);
        alert("Error loading event details.");
    }
}

// Handle Registration Form Submission
function handleRegistration(event) {
    event.preventDefault();

    const firstName = document.getElementById("firstName").value.trim();
    const lastName = document.getElementById("lastName").value.trim();
    const email = document.getElementById("email").value.trim();

    if (firstName === "" || lastName === "" || email === "") {
        alert("Error: Please fill in all fields.");
        return;
    }

    if (!email.includes("@")) {
        alert("Error: Please enter a valid email address.");
        return;
    }

    alert("You are successfully registered to this event!");
    window.location.href = "index.html";
}

// =====================================================
// ADMIN LOGIN FUNCTIONS (admin-login.html)
// =====================================================

const ADMIN_CREDENTIALS = {
    email: "admin@upgrad.com",
    password: "12345"
};

function handleAdminLogin(event) {
    event.preventDefault();

    const emailInput = document.getElementById("adminEmail").value.trim();
    const passwordInput = document.getElementById("adminPassword").value.trim();
    const alertBox = document.getElementById("loginAlert");

    if (!emailInput || !passwordInput) {
        showAlert(alertBox, "Please fill in all fields.");
        return;
    }

    if (emailInput === ADMIN_CREDENTIALS.email && passwordInput === ADMIN_CREDENTIALS.password) {
        hideAlert(alertBox);
        localStorage.setItem("isAdminLoggedIn", "true");
        alert("Login Successful! Redirecting to Dashboard...");
        window.location.href = "admin-dashboard.html";
    } else {
        showAlert(alertBox, "Invalid email or password!");
    }
}

function showAlert(alertElement, message) {
    if (!alertElement) return;
    alertElement.textContent = message;
    alertElement.classList.remove("d-none");
    alertElement.classList.add("alert-danger");
    alertElement.classList.remove("alert-success");
}

function hideAlert(alertElement) {
    if (!alertElement) return;
    alertElement.classList.add("d-none");
}

// =====================================================
// ADMIN DASHBOARD FUNCTIONS (admin-dashboard.html)
// =====================================================

// Display Events as Bootstrap Cards on Dashboard
function displayDashboardEvents(events) {
    const container = document.getElementById("eventsContainer");
    const emptyMsg = document.getElementById("emptyMessage");
    
    if (!container) return;

    container.innerHTML = "";

    if (events.length === 0) {
        if (emptyMsg) emptyMsg.classList.remove("d-none");
        return;
    }
    
    if (emptyMsg) emptyMsg.classList.add("d-none");

    events.forEach(event => {
        const card = `
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <span class="badge bg-info mb-2">${event.category}</span>
                        <h5 class="card-title">${event.name}</h5>
                        <p class="card-text"><strong>ID:</strong> ${event.id}</p>
                        <p class="card-text"><strong>Date:</strong> ${event.date} at ${event.time}</p>
                        <p class="card-text">${event.description || "No description"}</p>
                        ${event.url ? `<a href="${event.url}" target="_blank" class="btn btn-sm btn-outline-primary">Visit Link</a>` : ''}
                    </div>
                    <div class="card-footer bg-white border-0">
                        <button class="btn btn-danger btn-sm w-100" onclick="handleDeleteEvent(${event.id})">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}

// Load Events on Dashboard
async function loadDashboardEvents() {
    if (!document.getElementById("eventsContainer")) return;

    try {
        await openDatabase();
        const events = await getAllEventsFromDB();
        displayDashboardEvents(events);
    } catch (error) {
        alert("Error loading events: " + error);
        console.error(error);
    }
}

// Handle Add Event Form Submission
async function handleAddEvent(event) {
    event.preventDefault();

    const newEvent = {
        id: parseInt(document.getElementById("newEventId").value),
        name: document.getElementById("newEventName").value.trim(),
        category: document.getElementById("newEventCategory").value,
        date: document.getElementById("newEventDate").value,
        time: document.getElementById("newEventTime").value,
        url: document.getElementById("newEventUrl").value.trim(),
        description: document.getElementById("newEventDesc").value.trim()
    };

    try {
        await openDatabase();
        await addEventToDB(newEvent);
        
        const modal = bootstrap.Modal.getInstance(document.getElementById("addEventModal"));
        modal.hide();
        
        document.getElementById("addEventForm").reset();
        alert("Event added successfully!");
        loadDashboardEvents();
        
    } catch (error) {
        alert(error);
    }
}

// Handle Delete Button Click
async function handleDeleteEvent(eventId) {
    if (!confirm("Are you sure you want to delete this event?")) {
        return;
    }

    try {
        await openDatabase();
        await deleteEventFromDB(eventId);
        alert("Event deleted!");
        loadDashboardEvents();
    } catch (error) {
        alert("Error deleting event: " + error);
    }
}

// Handle Search
async function handleSearch() {
    const searchTerm = document.getElementById("searchInput").value.trim();
    
    if (!searchTerm) {
        loadDashboardEvents();
        return;
    }

    try {
        await openDatabase();
        const results = await searchEventsFromDB(searchTerm);
        displayDashboardEvents(results);
    } catch (error) {
        alert("Search error: " + error);
    }
}

// Handle Logout
function handleAdminLogout() {
    localStorage.removeItem("isAdminLoggedIn");
    alert("Logged out successfully!");
    window.location.href = "admin-login.html";
}

// Check Admin Authentication
function checkAdminAuth() {
    if (document.getElementById("eventsContainer")) {
        if (localStorage.getItem("isAdminLoggedIn") !== "true") {
            alert("Please login first!");
            window.location.href = "admin-login.html";
        }
    }
}

// =====================================================
// CONTACT FORM FUNCTIONS (contact.html)
// =====================================================

function handleContactSubmit(event) {
    event.preventDefault();

    const form = document.getElementById("contactForm");
    const name = document.getElementById("contactName").value.trim();
    const email = document.getElementById("contactEmail").value.trim();
    const message = document.getElementById("contactMessage").value.trim();
    const successAlert = document.getElementById("contactSuccess");

    if (name === "" || email === "" || message === "") {
        alert("Error: Please fill in all required fields.");
        return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Error: Please enter a valid email address.");
        return;
    }

    if (message.length < 10) {
        alert("Error: Message must be at least 10 characters long.");
        return;
    }

    if (successAlert) {
        successAlert.classList.remove("d-none");
        successAlert.scrollIntoView({ behavior: "smooth" });
    }

    form.reset();
    console.log("Contact Form Submitted:", { name, email, message });

    setTimeout(function() {
        if (successAlert) {
            successAlert.classList.add("d-none");
        }
    }, 5000);
}

// =====================================================
// GLOBAL PAGE LOAD INITIALIZATION
// =====================================================

window.addEventListener("load", async function() {
    
    // 1. Initialize Database (add default events if empty)
    await initializeDatabase();

    // 2. Home Page: Load Events
    loadHomeEvents();

    // 3. Registration Page: Load Event Details
    loadRegistrationPage();

    // 4. Admin Login: Attach Form Listener
    const loginForm = document.getElementById("adminLoginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", handleAdminLogin);
    }

    // 5. Admin Dashboard: Setup All Functions
    if (document.getElementById("eventsContainer")) {
        checkAdminAuth();
        
        const addForm = document.getElementById("addEventForm");
        if (addForm) {
            addForm.addEventListener("submit", handleAddEvent);
        }

        const searchBtn = document.getElementById("searchBtn");
        if (searchBtn) {
            searchBtn.addEventListener("click", handleSearch);
        }
        
        const searchInput = document.getElementById("searchInput");
        if (searchInput) {
            searchInput.addEventListener("keypress", function(e) {
                if (e.key === "Enter") handleSearch();
            });
        }

        const logoutBtn = document.getElementById("logoutBtn");
        if (logoutBtn) {
            logoutBtn.addEventListener("click", handleAdminLogout);
        }

        loadDashboardEvents();
    }

    // 6. Contact Page: Attach Form Listener
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", handleContactSubmit);
    }
});